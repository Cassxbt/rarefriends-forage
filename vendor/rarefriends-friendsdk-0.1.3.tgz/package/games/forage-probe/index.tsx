"use client";

import { useEffect, useState } from "react";
import { createPublicClient, formatUnits, http, parseAbi } from "viem";
import type { GameComponentProps } from "@rarefriends/friendsdk/runtime";
import "./style.css";

const RPC = "https://rpc.mainnet.chain.robinhood.com";
const GENERATIONS = "0x14C49e6118F46525dE9ab41a51cBAA3c6EBF181D";
const ACTIVATION_MANAGER = "0xD4A35e11318E3679168d409184B788bcF9F283Ac";
const RF = "0x0779369854d3EcdEA927206718FFD7730C67B71f";
const abi = parseAbi([
  "function generation(uint256) view returns (uint8)",
  "function positions(address, uint256) view returns (uint256 tier, uint256 weight)",
  "function earned(address, address, uint256) view returns (uint256)",
  "function weth() view returns (address)",
]);
const chain = createPublicClient({ transport: http(RPC) });

type Reading = { block: bigint; generation: number; tier: bigint; weight: bigint; earnedRf: bigint; earnedWeth: bigint };

async function readFriend(friendId: bigint): Promise<Reading> {
  const blockNumber = await chain.getBlockNumber();
  const at = { blockNumber } as const;
  const weth = await chain.readContract({ address: ACTIVATION_MANAGER, abi, functionName: "weth", ...at });
  const [generation, [tier, weight], earnedRf, earnedWeth] = await Promise.all([
    chain.readContract({ address: GENERATIONS, abi, functionName: "generation", args: [friendId], ...at }),
    chain.readContract({ address: ACTIVATION_MANAGER, abi, functionName: "positions", args: [GENERATIONS, friendId], ...at }),
    chain.readContract({ address: ACTIVATION_MANAGER, abi, functionName: "earned", args: [RF, GENERATIONS, friendId], ...at }),
    chain.readContract({ address: ACTIVATION_MANAGER, abi, functionName: "earned", args: [weth, GENERATIONS, friendId], ...at }),
  ]);
  return { block: blockNumber, generation, tier, weight, earnedRf, earnedWeth };
}

/** Throwaway probe: proves the sandboxed game can read the selected Friend's live on-chain state. */
export default function ForageProbe({ friendId }: GameComponentProps) {
  const [reading, setReading] = useState<Reading | null>(null);
  const [error, setError] = useState("");
  const [reads, setReads] = useState(0);

  useEffect(() => {
    let active = true;
    const poll = () => readFriend(friendId)
      .then(value => { if (active) { setReading(value); setError(""); setReads(n => n + 1); } })
      .catch(cause => { if (active) setError(cause instanceof Error ? cause.message : String(cause)); });
    void poll();
    const timer = setInterval(poll, 10_000);
    return () => { active = false; clearInterval(timer); };
  }, [friendId]);

  return (
    <main className="probe">
      <h1>Forage probe · Friend #{friendId.toString()}</h1>
      <p>Live reads from inside the game sandbox. Read-only. Refreshes every 10 s.</p>
      {error && <p className="probe-error">Read failed: {error}</p>}
      {!reading && !error && <p>Reading the chain…</p>}
      {reading && (
        <dl>
          <dt>Block</dt><dd>{reading.block.toString()}</dd>
          <dt>Generation</dt><dd>{reading.generation}</dd>
          <dt>Tier</dt><dd>{reading.tier.toString()}</dd>
          <dt>Weight</dt><dd>{formatUnits(reading.weight, 18)}</dd>
          <dt>Earned RF</dt><dd>{formatUnits(reading.earnedRf, 18)}</dd>
          <dt>Earned WETH</dt><dd>{formatUnits(reading.earnedWeth, 18)}</dd>
          <dt>Successful reads</dt><dd>{reads}</dd>
        </dl>
      )}
    </main>
  );
}
