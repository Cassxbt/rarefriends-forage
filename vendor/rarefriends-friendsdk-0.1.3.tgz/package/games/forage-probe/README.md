# Forage probe

Throwaway check that a sandboxed FriendSDK game can read the selected Friend's live on-chain state (generation, tier, weight, earned RF/WETH) from the Robinhood RPC. Read-only; no transactions. Not a submission.

Run from the SDK root: `npm run dev:game -- games/forage-probe`
